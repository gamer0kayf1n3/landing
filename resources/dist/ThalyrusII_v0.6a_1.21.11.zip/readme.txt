INSTALLATION
════════════════════════════════════════

1) Launch Minecraft and click on "Options"

2) Click on "Resource Packs"

3) Click on "Open Pack Folder"

4) Drag the ThalyrusII.zip file into the folder

5) Select the Thalyrus II.zip resource pack from 
the left column and move it to the top of the 
"Selected Resource Packs" column

6) Select "Done", the game will now start to 
load the texture pack



LINKS
════════════════════════════════════════

Discord:
https://discord.gg/cgDuwnm

Official website:
https://zachopixel.com

Ko-fi:
https://ko-fi.com/zachopixel

CurseForge:
https://www.curseforge.com/members/zacho/projects

Modrinth
https://modrinth.com/user/zacho

Planet Minecraft
https://www.planetminecraft.com/member/zacho

Youtube:
https://www.youtube.com/@ZachoPix



MODS RECOMMENDED
════════════════════════════════════════

If you're playing on Forge:
- Optifine

If you're playing on Fabric:
- Sodium



OPTIFINE VIDEO SETTINGS
════════════════════════════════════════

- Quality > Custom Items: ON
- Quality > Connected Textures: Fast
- Quality > Custom Entity Models: ON
- Quality > Random Entities: ON
- Details > Alternate Blocks: ON
- Smooth lighting: Minimum
- Dynamic light: Fancy



SHADERS RECOMMENDED
════════════════════════════════════════

Complementary Shaders - Reimagined:

https://modrinth.com/shader/complementary-reimagined



CREDITS
════════════════════════════════════════

- Sky: Custom Sky (Edit) By Rodrigo_Al
- Combat sounds and voices: Chivalry Medieval Warfare
- Font: 'Smooth Font' by Fire_Fist (Elisha V. Shaddock)



Thalyrus II 2026 © All rights reserved

Made By: ZachoPix
